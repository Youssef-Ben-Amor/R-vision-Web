import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eau',
  templateUrl: './eau.component.html',
  styleUrls: ['./eau.component.css']
})
export class EauComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
