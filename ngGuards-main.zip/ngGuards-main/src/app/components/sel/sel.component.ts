import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sel',
  templateUrl: './sel.component.html',
  styleUrls: ['./sel.component.css']
})
export class SelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
