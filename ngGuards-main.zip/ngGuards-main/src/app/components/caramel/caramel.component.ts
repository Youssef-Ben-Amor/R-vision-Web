import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caramel',
  templateUrl: './caramel.component.html',
  styleUrls: ['./caramel.component.css']
})
export class CaramelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
